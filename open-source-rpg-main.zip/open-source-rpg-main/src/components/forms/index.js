import CharacterInfoForm from "./CharacterInfoForm";

export {
    CharacterInfoForm
}