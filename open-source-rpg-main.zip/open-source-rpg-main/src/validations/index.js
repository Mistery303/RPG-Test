import CharacterInfoSchema from './CharacterInfoSchema';

export {
    CharacterInfoSchema
}